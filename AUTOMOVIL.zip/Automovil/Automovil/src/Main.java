import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Información de Automóvil
        System.out.println("Ingrese la marca del automóvil: ");
        String marca = scanner.nextLine();
        System.out.println("Ingrese el modelo del automóvil: ");
        String modelo = scanner.nextLine();
        System.out.println("Ingrese el color del automóvil: ");
        String color = scanner.nextLine();
        System.out.println("Ingrese el cilindraje del automóvil: ");
        double cilindraje = scanner.nextDouble();
        scanner.nextLine(); // Limpiar el buffer de entrada

        Automovil automovil = new Automovil(marca, modelo, color, cilindraje);

        // Mostrar la "factura" de información de Automóvil
        System.out.println("\nINFORMACION DEL AUTOMOVIL:");
        System.out.println(automovil.detalleAutomovil());
    }
}
