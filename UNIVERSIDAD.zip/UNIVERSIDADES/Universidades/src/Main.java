import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner scanner= new Scanner(System.in);

        //infor uni

        System.out.println(" Ingrese el nombre de la universidad: ");
        String nombreUniversidad = scanner.nextLine();
        System.out.println("Ingrese la direccion: ");
        String nombreDireccion= scanner.nextLine();
        System.out.println("Ingrese el ID");
        String nombreId=scanner.nextLine();

        Universidades universidades = new Universidades(nombreUniversidad,nombreDireccion,nombreId);

        //infoestudiantes

        System.out.println("Ingrese el nombre del estudiante:");
        String nombreEstudiante = scanner.nextLine();
        System.out.println("Ingrese la carrera del estudiante:");
        String nombreCarrera = scanner.nextLine();
        System.out.println("Ingrese el correo del esutdiante:");
        String nombreCorreo = scanner.nextLine();

        Estudiantes estudiantes = new Estudiantes(nombreEstudiante,nombreCarrera,nombreCorreo);

        //info materia

        System.out.println(" Ingrese la materia 1 :");
        String nombreMateria1 = scanner.nextLine();
        System.out.println(" Ingrese la materia 2 :");
        String nombreMateria2 = scanner.nextLine();
        System.out.println(" Ingrese la materia 3 :");
        String nombreMateria3 = scanner.nextLine();

        Materia materia = new Materia(nombreMateria1,nombreMateria2,nombreMateria3);

        //infocurso

        System.out.println("Ingrese el curso 1");
        String nombreCurso1 = scanner.nextLine();
        System.out.println("Ingrese el curso 2");
        String nombreCurso2 = scanner.nextLine();
        System.out.println("Ingrese el curso 3");
        String nombreCurso3 = scanner.nextLine();

        Curso curso = new Curso(nombreCurso1,nombreCurso2,nombreCurso3);


        System.out.println("INFORMACION UNIVERSIDADES : \n");
        System.out.println(universidades.detalleUniversidad());
        System.out.println("INFORMACION ESTUDIANTES: \n ");
        System.out.println(estudiantes.detalleEstudiante());
        System.out.println("INFORMACION MATERIAS: \n");
        System.out.println(materia.detalleMateria());
        System.out.println("INFORMACION CURSO: \n");
        System.out.println(curso.detalleCurso());













    }
}