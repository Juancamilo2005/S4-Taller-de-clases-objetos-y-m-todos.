public class Materia {
    private String Materia1;
    private String Materia2;
    private String Materia3;

    public Materia() {
    }

    public Materia(String materia2, String materia1, String materia3) {
        Materia2 = materia2;
        Materia1 = materia1;
        Materia3 = materia3;
    }

    public String getMateria2() {
        return Materia2;
    }

    public void setMateria2(String materia2) {
        Materia2 = materia2;
    }

    public String getMateria1() {
        return Materia1;
    }

    public void setMateria1(String materia1) {
        Materia1 = materia1;
    }

    public String getMateria3() {
        return Materia3;
    }

    public void setMateria3(String materia3) {
        Materia3 = materia3;
    }

    public String detalleMateria(){
        return "La materia 1 es :" + this.Materia1 + ("\n") +
                "La materia 2 es :" + this.Materia2 + ("\n") +
                "La materia 3 es :" + this.Materia3 + ("\n") ;
    }
}
