public class Universidades {
    private String Nombre;
    private String Direccion;
    private String Id;

    public Universidades() {
    }

    public Universidades(String id, String nombre, String direccion) {
        Id = id;
        Nombre = nombre;
        Direccion = direccion;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String detalleUniversidad(){
        return "El nombre de la universidad es: " + this.Nombre + ("\n")+
                "La direccion de la universidad es: " + this.Direccion + ("\n")+
                "El id de la universidad es: " + this.Id + ("\n");

    }
}
