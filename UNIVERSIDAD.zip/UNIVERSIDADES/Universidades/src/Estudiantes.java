public class Estudiantes {
    private String Nombre;
    private String Carrera;
    private String Correo;

    public Estudiantes() {
    }

    public Estudiantes(String carrera, String nombre, String correo) {
        Carrera = carrera;
        Nombre = nombre;
        Correo = correo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String carrera) {
        Carrera = carrera;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }
    public String detalleEstudiante(){
        return "El nombre del estudiantes es:" + this.Nombre + ("\n") +

                "la carrera del estudiantes es:" + this.Carrera + ("\n") +

                "El correo del estudiantes es:" + this.Correo + ("\n");
    }
}