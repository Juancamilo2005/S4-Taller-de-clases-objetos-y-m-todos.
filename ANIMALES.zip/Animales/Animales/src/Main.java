import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Información de Animal
        System.out.println("Ingrese el tipo de animal: ");
        String tipo = scanner.nextLine();
        System.out.println("Ingrese la raza del animal: ");
        String raza = scanner.nextLine();
        System.out.println("Ingrese el color del animal: ");
        String color = scanner.nextLine();
        System.out.println("Ingrese la edad del animal: ");
        int edad = scanner.nextInt();

        Animal animal = new Animal(tipo, raza, color, edad);

        // Mostrar la "factura" de información de Animal
        System.out.println("\nINFORMACION DEL ANIMAL:");
        System.out.println(animal.detalleAnimal());
    }
}
