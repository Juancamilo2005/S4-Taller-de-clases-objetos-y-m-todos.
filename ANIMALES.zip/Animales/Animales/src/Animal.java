public class Animal {
    private String tipo;
    private String raza;
    private String color;
    private int edad;

    public Animal(String tipo, String raza, String color, int edad) {
        this.tipo = tipo;
        this.raza = raza;
        this.color = color;
        this.edad = edad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String detalleAnimal() {
        return "Tipo: " + this.tipo + "\n" +
                "Raza: " + this.raza + "\n" +
                "Color: " + this.color + "\n" +
                "Edad: " + this.edad + " años\n";
    }
}
